// const LaunchesPage = require('./launches.page')
// const LoginPage = require('./login.pagee')
// const SecurePage = require('./secure.page')

// module.exports = {
//   LoginPage,
//   LaunchesPage,
//   SecurePage,
// };
