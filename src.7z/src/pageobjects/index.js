// const pages = require('./pages');

// module.exports = {
//   ...pages,
// };
